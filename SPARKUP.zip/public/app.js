// public/app.js
document.addEventListener('DOMContentLoaded', () => {
  const contButton = document.getElementById('contButton');

  contButton.addEventListener('click', () => {
    // Use the history API to change the URL without triggering a full page reload
    history.pushState(null, null, '/login');
    loadLoginContent();
  });

  function loadLoginContent() {
    // Fetch and replace content for the login section
    fetch('/login')
      .then(response => response.text())
      .then(html => {
        const appContainer = document.getElementById('appContainer');
        appContainer.innerHTML = html;
      });
  }
});
